// This project toggles the blue LED on the
// PSoC4 Pioneer Board every second

#include <project.h>

uint16 ms_count = 0;

CY_ISR(MY_ISR) {
	ms_count++;
	
	if(ms_count == 1000) { // 1 second
		LED_Write(!LED_Read()); // Toggle LED
		ms_count = 0; // reset ms counter
	}
}

int main()
{
    Timer_1_Start(); // Configure and enable timer
	isr_1_StartEx(MY_ISR); // Point to MY_ISR to carry out the interrupt sub-routine

    CyGlobalIntEnable; // Enable global interrupts
    
	for(;;)
    {
        // Infinite loop for timer/interrupt to keep executing
    }
}

/* [] END OF FILE */
