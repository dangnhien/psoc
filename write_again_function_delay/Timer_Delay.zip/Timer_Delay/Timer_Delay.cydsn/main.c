// This project demonstrates how to use a timer to create
// blocking delays. It toggles the red and blue LEDs on
// the PSoC4 Pioneer Board every 1/2 second.

#include <project.h>

#define ON 0
#define OFF 1
#define TIMER_CLOCK 24000000 // This value should match the clock input to the Timer

uint8 timer_flag = 0;

void ms_delay (uint32 ms);
void us_delay (uint32 us);

CY_ISR(MY_ISR) {

	timer_flag = 1;
}

int main()
{
	Blue_LED_Write(ON);
	Red_LED_Write(OFF);
	
	Timer_1_Init(); // config but don't start the timeout counter
	isr_1_StartEx(MY_ISR); // setup timer interrupt sub-routine
	CyGlobalIntEnable; // enable global interrupts
    
	for(;;)
    {
		ms_delay(500); // delay 1/2 second
		// Toggle LEDs
		Blue_LED_Write(!Blue_LED_Read());
		Red_LED_Write(!Red_LED_Read());
		
		us_delay(500000); // delay 1/2 second
		// Toggle LEDs
		Blue_LED_Write(!Blue_LED_Read());
		Red_LED_Write(!Red_LED_Read());
    }
}

// This function can be used for delays in units of ms.
// Valid value of ms can be in the range [0 ~ 4,294,967,295].
void ms_delay (uint32 ms) {
	uint32 period = TIMER_CLOCK/1000*ms;
	Timer_1_WritePeriod(period);
	Timer_1_Enable(); // start the timeout counter
	while(!timer_flag);
	Timer_1_Stop();
	timer_flag = 0;
}

// This function can be used for delays in units of us.
// Valid value of us can be in the range [0 ~ 4,294,967,295].
void us_delay (uint32 us) {
	uint32 period = TIMER_CLOCK/1000/1000*us;
	Timer_1_WritePeriod(period);
	Timer_1_Enable(); // start the timeout counter
	while(!timer_flag);
	Timer_1_Stop();
	timer_flag = 0;
}


/* [] END OF FILE */
